$( function() {
	$( '#authors' ).hover( function(e) {
		$( '#hire' ).show();

	}, function(e) {
		$( '#hire' ).hide();		
	});
});